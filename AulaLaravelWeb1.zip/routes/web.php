<?php

use App\Http\Controllers\UsuarioController;


Route::get('/', function () {
    return view('welcome');
});

/*
Route::get('/usuario{param}', function (){
    return view("UsuarioList");
});
*/

Route::get('/usuario', [UsuarioController::class, 'index']);



